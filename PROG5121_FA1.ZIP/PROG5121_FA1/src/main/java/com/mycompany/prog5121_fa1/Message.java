package com.mycompany.prog5121_fa1;

import java.util.Random;

public class Message {
    private String messageID;
    private int numMessages;
    private String recipient;
    private String messageText;
    private String messageHash;
    private static int totalMessages = 0;

    public Message(String recipient, String messageText, int numMessages) {
        this.recipient = recipient;
        this.messageText = messageText;
        this.numMessages = numMessages;
        this.messageID = String.valueOf(1000000000L + (long)(new Random().nextDouble() * 9000000000L));
        this.messageHash = createMessageHash();
    }
    public Message(String messageID, String recipient, String messageText, int numMessages) {
        this.messageID = messageID;
        this.recipient = recipient;
        this.messageText = messageText;
        this.numMessages = numMessages;
        this.messageHash = createMessageHash();
    }
    public boolean checkMessageID() { return messageID.length() <= 10; }
    public String checkRecipientCell() {
        if (recipient.startsWith("+") && recipient.matches("\\+\\d+") && recipient.length() <= 13) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }
    public String createMessageHash() {
        String firstTwo = messageID.substring(0, 2);
        String[] words = messageText.trim().split("\\s+");
        String first = words[0].replaceAll("[^A-Za-z]", "");
        String last = words[words.length-1].replaceAll("[^A-Za-z]", "");
        return (firstTwo + ":" + numMessages + ":" + first + last).toUpperCase();
    }
    public String checkMessageLength() {
        if (messageText.length() <= 250) return "Message ready to send.";
        int over = messageText.length() - 250;
        return "Message exceeds 250 characters by " + over + ", please reduce the size.";
    }
    public String SentMessage(int choice) {
        if (choice == 1) { totalMessages++; return "Message successfully sent."; }
        if (choice == 2) return "Press 0 to delete the message.";
        if (choice == 3) { return "Message successfully stored."; }
        return "Invalid";
    }
    public String printMessages() { return "MessageID: " + messageID + "\nMessageHash: " + messageHash + "\nRecipient: " + recipient + "\nMessage: " + messageText; }
    public int returnTotalMessagess() { return totalMessages; }
    public String getMessageID() { return messageID; }
    public String getMessageHash() { return messageHash; }
}