package com.mycompany.prog5121_fa1;

import java.util.Scanner;

public class PROG5121_FA1 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter First Name: ");
        String first = input.nextLine();
        System.out.print("Enter Last Name: ");
        String last = input.nextLine();
        
        Login login = new Login(first, last);
        
        System.out.print("\nEnter username (Bee_3): ");
        String username = input.nextLine();
        System.out.print("Enter password (Beekay@10): ");
        String password = input.nextLine();
        System.out.print("Enter cell (+27826050481): ");
        String cell = input.nextLine();
        
        System.out.println(login.registerUser(username, password, cell));
        
        System.out.print("\nLogin Username: ");
        String lu = input.nextLine();
        System.out.print("Login Password: ");
        String lp = input.nextLine();
        
        boolean ok = login.loginUser(lu, lp);
System.out.println(login.returnLoginStatus(lu, lp));
if (!ok) return;
        
        System.out.println("\nWelcome to QuickChat.");
        System.out.print("How many messages? ");
        int limit = Integer.parseInt(input.nextLine());
        
        int sentCount = 0;
        Message temp = new Message("+27718693002", "Hi", 0);
        
        while (sentCount < limit) {
            System.out.println("\n1) Send Messages  2) Show recently sent (Coming Soon)  3) Quit");
            System.out.print("Choose: ");
            int choice = Integer.parseInt(input.nextLine());
            
            if (choice == 1) {
                System.out.print("Recipient: ");
                String recipient = input.nextLine();
                System.out.print("Message: ");
                String text = input.nextLine();
                
                Message msg = new Message(recipient, text, sentCount);
                System.out.println(msg.checkRecipientCell());
                System.out.println(msg.checkMessageLength());
                if (text.length() > 250) continue;
                
                System.out.println("1) Send  2) Disregard  3) Store");
                int opt = Integer.parseInt(input.nextLine());
                System.out.println(msg.SentMessage(opt));
                
                if (opt == 1) {
                    System.out.println(msg.printMessages());
                    sentCount++;
                } else if (opt == 3) {
                    sentCount++;
                }
            } else if (choice == 2) {
                System.out.println("Coming Soon.");
            } else if (choice == 3) {
                break;
            }
        }
        System.out.println("Total: " + temp.returnTotalMessagess());
    }
}